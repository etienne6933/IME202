package javaproj.src;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {

	public static void main(String[] args) throws Exception {

		ArrayList<Patient> patients = new ArrayList<>();		// Cr�ation d'une ArrayList qui va contenir tous les patients

		fillData(new File("C:\\temp\\IME202\\javaproj\\traitement\\Sejour.txt"), patients);		// On remplit patients gr�ce au fichier sejour (seuls les patients n'�tant pas d�j� enregistr�s seront ajout�s)
		fillData(new File("C:\\temp\\IME202\\javaproj\\traitement\\PMSI.txt"), patients);		// On remplit patients gr�ce au fichier pmsi (seuls les patients n'�tant pas d�j� enregistr�s seront ajout�s)
		fillData(new File("C:\\temp\\IME202\\javaproj\\traitement\\Anapath.txt"), patients);	// On remplit patients gr�ce au fichier anapath (seuls les patients n'�tant pas d�j� enregistr�s seront ajout�s)

		PrintWriter outputFile = new PrintWriter("C:\\temp\\IME202\\javaproj\\traitement\\TRAITS.txt", "UTF-8");		// Cr�ation d'un fichier TRAITS.txt
		outputFile.write("NumPatient|Sexe|DateNaissance|Prenom|Nom\n");		// Ajout en premi�re ligne de TRAITS.txt les noms des colonnes

		for (Patient patient : patients) {		// Ajout de tous les patients dans le fichier TRAITS.txt
			outputFile.write(patient.getId() + "|" + patient.getGender() + "|" + patient.getBirthDate() + "|" +		// Ajout du patient dans le fichier TRAITS.txt
					patient.getFirstName() + "|" + patient.getLastName() + "\n");
		}

        outputFile.close();		// Fermeture du fichier

        System.out.println("Fichier TRAITS.txt a �t� cr��...");

		createDatabase(patients);		// Ecriture du r�sultat dans la base de donn�e

	}

	private static void fillData(File file, ArrayList<Patient> patients) throws IOException {		// Fonction remplissant l'ArrayList patients gr�ce aux donn�es du fichier file
		HashMap<String, String> months = new HashMap<String, String>() {{
			put("JAN", "01"); put("FEB", "02"); put("MAR", "03"); put("APR", "04"); put("MAY", "05"); put("JUN", "06");
			put("JUL", "07"); put("AUG", "08"); put("SEP", "09"); put("OCT", "10"); put("NOV", "11"); put("DEC", "12");
		}};

		try (BufferedReader brSejour = new BufferedReader(new InputStreamReader(		// Utilisation de BufferedReader pour lire les lignes du fichier
				new FileInputStream(file), StandardCharsets.UTF_8))) {

			brSejour.readLine(); 								// Suppression de la premi�re ligne contenant les noms des colonnes
			String currentLine = brSejour.readLine();			// Stockage dans currentLine la ligne suivante

			while (currentLine != null) {
				String[] infos = currentLine.split("\\|");		// S�paration des mots � chaque |

				int id = Integer.parseInt(infos[0]);
				int gender = Integer.parseInt(infos[1]);
				String birthDate = infos[2].substring(5, 9) + "-" + months.get(infos[2].substring(2, 5)) + "-" +
						infos[2].substring(0, 2);
				String firstName = infos[3].replace("�", "É");
				String lastName = infos[4].replace("�", "É");

				Patient currentPatient = new Patient(id, gender, birthDate, firstName, lastName);		// Cr�ation du nouveau patient

				if (!patients.contains(currentPatient)) {		// V�rification si la liste contient d�j� le patient
					patients.add(currentPatient);
				}

				currentLine = brSejour.readLine();		// Passage à la ligne suivante
			}
		} catch (IOException ignored) {
			throw new IOException("files not found");
		}
	}

	private static void createDatabase(ArrayList<Patient> patients) throws Exception {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Class loaded...");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/", "root", "");		// Connection � la base de donn�e
			Statement statement = connection.createStatement();
			statement.execute("DROP DATABASE IF EXISTS patients");		// Suppression de la table patients
			statement.execute("CREATE DATABASE patients");		// Cr�ation de la base de donn�e patients
			System.out.println("Database patients has been created...");
			statement.execute("CREATE TABLE patients.PATIENTS ("		// Cr�ation de la table PATIENTS
					+ "NumPatient INT NOT NULL,"
					+ "Gender INT NOT NULL,"
					+ "BirthDate VARCHAR(10),"
					+ "FirstName VARCHAR(50) NOT NULL,"
					+ "LastName VARCHAR(50) NOT NULL)");

			System.out.println("Table PATIENTS has been created...");

			for (Patient patient : patients) {		// Insertion des patients dans la table PATIENTS
				statement.execute("INSERT INTO patients.PATIENTS VALUES("
						+ patient.getId() + ","
						+ patient.getGender() + " ,'"
						+ patient.getBirthDate() + "' ,'"
						+ patient.getFirstName().replace("'", "`") + "' ,'"		// Remplacement des ' dans le pr�nom par des ` pour ne causer d'erreurs SQL
						+ patient.getLastName().replace("'", "`") + "')");
			}

			System.out.println("Table PATIENTS has been filled...");

			connection.close();

		} catch (Exception e) {
			throw new Exception(e);
		}
	}

}
