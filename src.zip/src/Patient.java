package javaproj.src;

public class Patient {

    private int id;                 // Num�ro d'identification du patient
    private int gender;             // Genre du patient (1 : Masculin, 2 : F�minin)
    private String birthDate;       // Date de naissance du patient
    private String firstName;       // Pr�nom du patient
    private String lastName;        // Nom de famille du patient

    public Patient(int id, int gender, String birthDate, String firstName, String lastName) {
        this.id = id;
        this.gender = gender;
        this.birthDate = birthDate;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public int getGender() {
        return gender;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    @Override
    public String toString() {
        return id + " : " + gender + " : " + firstName + " " + lastName + " : " + birthDate;
    }

    @Override
    public boolean equals(Object obj) {     // Fonction v�rifiant si deux patients sont similaires
        return this.id == ((Patient) obj).getId() && this.gender == ((Patient) obj).getGender() &&
                this.birthDate.equals(((Patient) obj).getBirthDate()) && this.firstName.equals(((Patient) obj).getFirstName()) &&
                this.lastName.equals(((Patient) obj).getLastName());
    }

}
